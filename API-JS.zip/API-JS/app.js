(function(){
    var app = angular.module ('store', [ ]);
//    app.controller('StoreController',function(){
//        this.products = gems;
//    });
   app.controller('StoreController',[ '$http',function($http){
    
 var store = this;
 
 store.apiresponse = "blank ";
 $http.get('http://localhost:8080/IS345RestWebService/rs/service/get').success(function(data){
     store.apiresponse = data;
 });
 }]);
  
})();